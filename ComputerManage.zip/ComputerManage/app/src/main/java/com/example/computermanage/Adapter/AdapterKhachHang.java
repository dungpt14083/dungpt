package com.example.computermanage.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.R;

import java.util.ArrayList;
import java.util.Random;

public class AdapterKhachHang extends RecyclerView.Adapter<AdapterKhachHang.KhachHangViewholder> {
    private Context context;
    ArrayList<KhachHang> khachHangArrayList;
    TextDrawable textDrawable;
    DAOKhachHang daoKhachHang;

    public AdapterKhachHang(Context context, ArrayList<KhachHang> khachHangArrayList) {
        this.context = context;
        this.khachHangArrayList = khachHangArrayList;
       daoKhachHang = new DAOKhachHang(context);
    }

    @NonNull
    @Override

    public KhachHangViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_khachhang,null);

        return new KhachHangViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KhachHangViewholder holder, int position) {

        KhachHang item = khachHangArrayList.get(position);
        holder.tvTenKhachHang_itemKhachHang.setText("Họ Tên: "+item.getHoten());
        holder.tvSDTKhachHang_itemkhachhang.setText("SĐT: "+item.getSdt());
        holder.tvGioiTinhKhachHang_itemKhachHang.setText("Giới Tính: "+item.getGioitinh());
        holder.tvdiachikhachhang_itemKhachHang.setText("Địa Chỉ: "+item.getDiachi());
        textDrawable = TextDrawable.builder().beginConfig().width(48).height(48).endConfig().buildRect(item.getHoten().substring(0, 1).toUpperCase(), getRamdomColor());

        holder.imganh_itemKhachHang.setImageDrawable(textDrawable);
        holder.imgxoa_itemKhachHang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int kq = daoKhachHang.deleteKhachHang(String.valueOf(item.getMskh()));
                if(kq>0)
                {
                    khachHangArrayList.clear();
                    khachHangArrayList.addAll(daoKhachHang.getAll());
                    notifyDataSetChanged();
                    Toast.makeText(context,"Xóa Thành Công",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(context,"Xóa Thất bại",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return khachHangArrayList.size();
    }

    public class KhachHangViewholder extends RecyclerView.ViewHolder{

        TextView tvSDTKhachHang_itemkhachhang;
        TextView tvTenKhachHang_itemKhachHang;
        TextView tvGioiTinhKhachHang_itemKhachHang;
        TextView tvdiachikhachhang_itemKhachHang;
        ImageButton imgxoa_itemKhachHang;
        ImageView imganh_itemKhachHang;


        public KhachHangViewholder(@NonNull View itemView) {
            super(itemView);
            tvTenKhachHang_itemKhachHang = itemView.findViewById(R.id.tvTenkhachhang_itemkhachhang);
            tvSDTKhachHang_itemkhachhang = itemView.findViewById(R.id.tvsodienthoaikhachhang_itemkhachhang);
            tvGioiTinhKhachHang_itemKhachHang = itemView.findViewById(R.id.tvgioitinh_itemkhachhang);
            tvdiachikhachhang_itemKhachHang = itemView.findViewById(R.id.tvDiaChi_itemkhachhang);
            imgxoa_itemKhachHang = itemView.findViewById(R.id.btnxoa_itemkhachhang);
            imganh_itemKhachHang = itemView.findViewById(R.id.imganh_itemkhachhang);
        }
    }
    public int getRamdomColor()
    {
        Random rnd = new Random();
        return Color.argb(255,rnd.nextInt(256),rnd.nextInt(256),rnd.nextInt(256));

    }
}
