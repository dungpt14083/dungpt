package com.example.computermanage.UI.HoaDonXuat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.computermanage.DAO.DAOAdmin;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.DAO.DAOHoaDonCT;
import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.DAO.DAONhanVien;
import com.example.computermanage.DAO.DAOSanPham;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.Model.HoaDonChiTiet;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.Model.SanPham;
import com.example.computermanage.R;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ActivityAddHoaDonXuat extends AppCompatActivity {
    TextInputEditText ed_maHD_xuat, ed_ngayHD_xuat, ed_soluongHD_xuat,
            ed_dongiaHD_xuat, ed_thanhtienHD_xuat;
    Spinner spn_sanphamxuat, spn_khachhangxuat, spn_khuyenmaixuat;
    RadioButton rdo_khongbaohanh_HD_xuat, rdo_6thang_HD_xuat, RDO_12thang_HD_xuat, rdo_dathanhtoan_HD, rdo_chuathanhtoan_HD;
    RadioGroup rdg_editbaohanh;
    ArrayList<SanPham> listSanpham;
    ArrayList<HoaDon> listHoadon;
    ArrayList<KhachHang> listKhachhang;
    ArrayList<HoaDonChiTiet> listHoadonCT;
    DAOSanPham daoSanPham;
    DAOHoaDon daoHoaDon;
    DAONhanVien daoNhanVien;
    DAOHoaDonCT daoHoaDonCT;
    DAOKhachHang daoKhachHang;
    DAOAdmin daoAdmin;
    private String maNV;
    private int khuyenmai;
    private double thanhtien;
    private double dongia;
    private int soluong;
    private int baoHanh;
    private String maSP;
    private Spinner spnKM;
    ArrayAdapter sanphamadapter;
    ArrayAdapter khachhangadapter;
    DecimalFormat decimalFormat;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hoa_don_xuat);
        addConTrol();
        getMaNV();
        setDataSpinner();

    }


    private void addConTrol() {
        ed_maHD_xuat = findViewById(R.id.ed_maHD_xuat);
        ed_ngayHD_xuat = findViewById(R.id.ed_ngayHD_xuat);
        ed_soluongHD_xuat = findViewById(R.id.ed_soluongHD_xuat);
        ed_dongiaHD_xuat = findViewById(R.id.ed_dongiaHD_xuat);
        spn_khuyenmaixuat = findViewById(R.id.spn_khuyenmaixuat);
        ed_thanhtienHD_xuat = findViewById(R.id.ed_thanhtienHD_xuat);
        spn_sanphamxuat = findViewById(R.id.spn_sanphamxuat);
        spn_khachhangxuat = findViewById(R.id.spn_khachhangxuat);
        rdo_khongbaohanh_HD_xuat = findViewById(R.id.rdo_khongbaohanh_HD_xuat);
        rdo_6thang_HD_xuat = findViewById(R.id.rdo_6thang_HD_xuat);
        RDO_12thang_HD_xuat = findViewById(R.id.RDO_12thang_HD_xuat);
        rdo_dathanhtoan_HD = findViewById(R.id.rdo_dathanhtoan_HD);
        rdo_chuathanhtoan_HD = findViewById(R.id.rdo_chuathanhtoan_HD);
        rdg_editbaohanh = findViewById(R.id.rdg_editbaohanh);
        toolbar = findViewById(R.id.tb_addHDXuat);
        spnKM = findViewById(R.id.spn_khuyenmaixuat);
        daoSanPham = new DAOSanPham(this);
        daoHoaDon = new DAOHoaDon(this);
        daoHoaDonCT = new DAOHoaDonCT(this);
        daoNhanVien = new DAONhanVien(this);
        daoAdmin = new DAOAdmin(this);
        daoKhachHang = new DAOKhachHang(this);
        listSanpham = new ArrayList<>();
        listHoadon = new ArrayList<>();
        listKhachhang = new ArrayList<>();
        listHoadonCT = new ArrayList<>();
        listKhachhang = daoKhachHang.getAll();
        listSanpham = daoSanPham.getAll();
        ed_dongiaHD_xuat.setEnabled(false);
        rdo_6thang_HD_xuat.setChecked(true);
        rdo_khongbaohanh_HD_xuat.setChecked(true);
        rdo_dathanhtoan_HD.setChecked(true);
        sanphamadapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listSanpham);
        spn_sanphamxuat.setAdapter(sanphamadapter);
        khachhangadapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listKhachhang);
        spn_khachhangxuat.setAdapter(khachhangadapter);
        decimalFormat = new DecimalFormat("###,###,###");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityAddHoaDonXuat.this,ActivityHoadonXuat.class));
            }
        });
    }

    public void getMaNV() {
        SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
        String taiKhoan = preferences.getString("user", "");
        if (daoNhanVien.getID(taiKhoan).getMsnv() == null) {
            Toast.makeText(getApplicationContext(), "Chua co nhan vien", Toast.LENGTH_SHORT).show();
            return;
        } else {
            maNV = daoNhanVien.getID(taiKhoan).getMsnv();
        }
    }

    private void eventDialog() {
        ed_soluongHD_xuat.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                Thanhtien();
                if (!b) {
                    if (Thanhtien() != 0) {
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(Thanhtien()) + "");
                    } else {
                        ed_thanhtienHD_xuat.setText("Null");
                    }
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_save, menu);
        return true;
    }

    private double Thanhtien() {
        try {
            double soluong = Double.parseDouble(ed_soluongHD_xuat.getText().toString());
            double dongia = Double.parseDouble(ed_dongiaHD_xuat.getText().toString());
            thanhtien = soluong * dongia;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return thanhtien;
    }


    private void setDataSpinner() {
        spn_sanphamxuat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maSP = String.valueOf(listSanpham.get(position).getMssp());
                dongia = listSanpham.get(position).getGiatien();
                try {
                    soluong = Integer.parseInt(ed_soluongHD_xuat.getText().toString());
                } catch (NumberFormatException ex) { // handle your exception

                }
                ed_soluongHD_xuat.setText(String.valueOf(1));
                ed_dongiaHD_xuat.setText(dongia + "");
                thanhtien = dongia * soluong;
                ed_thanhtienHD_xuat.setText(thanhtien + "");


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        eventDialog();
        setSpinnerKM();

    }
    public void formatBaoHanh() {
        if (rdo_khongbaohanh_HD_xuat.isChecked()) {
            baoHanh = -1;
        }
        if (rdo_6thang_HD_xuat.isChecked()) {
            baoHanh = 0;
        }
        if (RDO_12thang_HD_xuat.isChecked()) {
            baoHanh = 1;
        }
    }
    private void setSpinnerKM() {
        ArrayAdapter<CharSequence> spAdapter = ArrayAdapter.createFromResource(this, R.array.khuyenmai, R.layout.custom_item_sp);
        spAdapter.setDropDownViewResource(R.layout.custom_item_sp_drop_down);
        spnKM.setAdapter(spAdapter);
        spnKM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        khuyenmai = 1;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.05)) + " VNĐ");
                        break;
                    case 2:
                        khuyenmai = 2;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.1)) + " VNĐ");
                        break;
                    case 3:
                        khuyenmai = 3;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.15)) + " VNĐ");
                        break;
                    case 4:
                        khuyenmai = 4;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.2)) + " VNĐ");
                        break;
                    case 5:
                        khuyenmai = 5;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.25)) + " VNĐ");
                        break;
                    case 6:
                        khuyenmai = 6;
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.3)) + " VNĐ");
                        break;
                    case 0:
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien * 1) + " VNĐ");
                        khuyenmai = 0;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.menu_reset:

                return true;
            case R.id.menu_save:
                String mahd = ed_maHD_xuat.getText().toString();
                String ngay = ed_ngayHD_xuat.getText().toString();
                if (daoHoaDon.checkMaHD(mahd) > 0) {
                    Toast.makeText(this, "Mã hóa đơn đã tồn tại hệ thống", Toast.LENGTH_SHORT).show();
                } else {
                    HoaDon hoaDon = new HoaDon();
                    hoaDon.setMshd(mahd);
                    hoaDon.setMsnv(maNV);
                    KhachHang khachHang = (KhachHang) spn_khachhangxuat.getSelectedItem();
                    hoaDon.setMskh(String.valueOf(khachHang.getMskh()));
                    hoaDon.setPhanloaiHD(1);
                    hoaDon.setNgaymua(ngay);
                    if (rdo_dathanhtoan_HD.isChecked()) {
                        hoaDon.setTrangthai(1);
                    }
                    else if (rdo_chuathanhtoan_HD.isChecked()) {
                        hoaDon.setTrangthai(0);
                    }
                    long kq = daoHoaDon.insertHoaDon(hoaDon);
                    if (kq > 0) {
                        if (checkaddCTHD(hoaDon)) {
                            Toast.makeText(getApplicationContext(), "Thêm thành công hóa đơn", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(ActivityAddHoaDonXuat.this,ActivityHoadonXuat.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "Thêm chi tiết hóa đơn thất bại ", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    }
                }


        }
        return super.onOptionsItemSelected(item);
    }

    private boolean checkaddCTHD(HoaDon hoaDon) {
        for (SanPham sanPham : listSanpham) {
            HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
            SanPham sanPham1 = (SanPham) spn_sanphamxuat.getSelectedItem();
            hoaDonChiTiet.setMssp(String.valueOf(sanPham1.getMssp()));
            hoaDonChiTiet.setDongia(sanPham.getGiatien());
            hoaDonChiTiet.setSoluong(Integer.parseInt(ed_soluongHD_xuat.getText().toString()));
            hoaDonChiTiet.setMshd(hoaDon.getMshd());
            int rdgbaohanh=rdg_editbaohanh.getCheckedRadioButtonId();
            if (rdgbaohanh==R.id.rdo_editkhongbaohanh_DH) {
                hoaDonChiTiet.setBaohanh(0);
            } else if (rdgbaohanh==R.id.rdo_6thang_HD_xuat) {
                hoaDonChiTiet.setBaohanh(1);
            } else if (rdgbaohanh==R.id.RDO_12thang_HD_xuat) {
                hoaDonChiTiet.setBaohanh(2);
            }
            hoaDonChiTiet.setGiamgia(khuyenmai);
            long kqCT = daoHoaDonCT.insertHoaDonCT(hoaDonChiTiet);
            if (kqCT < 0) {
                return false;
            }
        }
        return true;
    }
}