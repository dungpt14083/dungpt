package com.example.computermanage.UI.HoaDonXuat;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.computermanage.DAO.DAOAdmin;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.DAO.DAOHoaDonCT;
import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.DAO.DAONhanVien;
import com.example.computermanage.DAO.DAOSanPham;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.Model.HoaDonChiTiet;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.Model.SanPham;
import com.example.computermanage.R;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ActivityAddHoaDonXuat extends AppCompatActivity {
    ActionBar actionBar;
    TextInputEditText ed_maHD_xuat, ed_ngayHD_xuat, ed_soluongHD_xuat,
            ed_dongiaHD_xuat, ed_thanhtienHD_xuat;
    Spinner spn_sanphamxuat, spn_khachhangxuat, spn_khuyenmaixuat;
    RadioButton rdo_khongbaohanh_HD_xuat, rdo_6thang_HD_xuat, RDO_12thang_HD_xuat, rdo_dathanhtoan_HD, rdo_chuathanhtoan_HD;
    ArrayList<SanPham> listSanpham;
    ArrayList<HoaDon> listHoadon;
    ArrayList<KhachHang> listKhachhang;
    DAOSanPham daoSanPham;
    DAOHoaDon daoHoaDon;
    DAONhanVien daoNhanVien;
    DAOHoaDonCT daoHoaDonCT;
    DAOKhachHang daoKhachHang;
    DAOAdmin daoAdmin;
    private String maNV;
    private int baohanh;
    private int khuyenmai;
    private int thanhtien;
    private String dongia;
    private String maSP;
    private String tenSP;
    private String soLuong;
    private Spinner spnKM;


    DecimalFormat decimalFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hoa_don_xuat);
        addConTrol();
        eventDialog();
    }




    private void addConTrol() {
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Thêm hóa đơn xuất");
        ed_maHD_xuat = findViewById(R.id.ed_maHD_xuat);
        ed_ngayHD_xuat = findViewById(R.id.ed_ngayHD_xuat);
        ed_soluongHD_xuat = findViewById(R.id.ed_soluongHD_xuat);
        ed_dongiaHD_xuat = findViewById(R.id.ed_dongiaHD_xuat);
        spn_khuyenmaixuat = findViewById(R.id.spn_khuyenmaixuat);
        ed_thanhtienHD_xuat = findViewById(R.id.ed_thanhtienHD_xuat);
        spn_sanphamxuat = findViewById(R.id.spn_sanphamxuat);
        spn_khachhangxuat = findViewById(R.id.spn_khachhangxuat);
        rdo_khongbaohanh_HD_xuat = findViewById(R.id.rdo_khongbaohanh_HD_xuat);
        rdo_6thang_HD_xuat = findViewById(R.id.rdo_6thang_HD_xuat);
        RDO_12thang_HD_xuat = findViewById(R.id.RDO_12thang_HD_xuat);
        rdo_dathanhtoan_HD = findViewById(R.id.rdo_dathanhtoan_HD);
        rdo_chuathanhtoan_HD = findViewById(R.id.rdo_chuathanhtoan_HD);
        daoSanPham = new DAOSanPham(this);
        daoHoaDon = new DAOHoaDon(this);
        daoHoaDonCT = new DAOHoaDonCT(this);
        daoNhanVien = new DAONhanVien(this);
        daoAdmin = new DAOAdmin(this);
        daoKhachHang = new DAOKhachHang(this);
        listSanpham = new ArrayList<>();
        listHoadon = new ArrayList<>();
        listKhachhang = new ArrayList<>();
        listKhachhang = daoKhachHang.getAll();
        listSanpham = daoSanPham.getAll();
        ArrayAdapter sanphamadapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listSanpham);
        spn_sanphamxuat.setAdapter(sanphamadapter);
        ArrayAdapter khachhangadapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listKhachhang);
        spn_khachhangxuat.setAdapter(khachhangadapter);
        decimalFormat = new DecimalFormat("###,###,###");
        getMaNV();
    }

    public void getMaNV() {
        SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
        String taiKhoan = preferences.getString("user", "");
        maNV = daoNhanVien.getID(taiKhoan).getMsnv();
        if (daoNhanVien.getID(taiKhoan).getMsnv() == null) {
            Toast.makeText(getApplicationContext(), "Chua co nhan vien", Toast.LENGTH_SHORT).show();
            return;
        } else {
            maNV = daoNhanVien.getID(taiKhoan).getMsnv();
        }
    }
    private void eventDialog() {
        ed_dongiaHD_xuat.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    if (Thanhtien() != 0) {
                        ed_thanhtienHD_xuat.setText(decimalFormat.format(Thanhtien()) + "");
                    } else {
                        ed_thanhtienHD_xuat.setText("Null");
                    }
                }
            }
        });
//        setSpinnerKM();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_save, menu);
        return true;
    }

    private double Thanhtien() {
        double thanhtien = 0;
        try {
            double soluong = Double.parseDouble(ed_soluongHD_xuat.getText().toString());
            double dongia = Double.parseDouble(ed_dongiaHD_xuat.getText().toString());
            thanhtien = soluong * dongia;
        } catch (Exception e) {
            thanhtien = 0;
        }
        return thanhtien;
    }



//    private void setSpinnerKM() {
//        ArrayAdapter<CharSequence> spAdapter = ArrayAdapter.createFromResource(this, R.array.khuyenmai, R.layout.custom_item_sp);
//        spAdapter.setDropDownViewResource(R.layout.custom_item_sp_drop_down);
//        spnKM.setAdapter(spAdapter);
//        spnKM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                switch (position) {
//                    case 1:
//                        khuyenmai = 1;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.05) + "đ"));
//                    case 2:
//                        khuyenmai = 2;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.1)) + " đ");
//                        break;
//                    case 3:
//                        khuyenmai = 3;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.15)) + " đ");
//                        break;
//                    case 4:
//                        khuyenmai = 4;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.2)) + " đ");
//                        break;
//                    case 5:
//                        khuyenmai = 5;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.25)) + " đ");
//                        break;
//                    case 6:
//                        khuyenmai = 6;
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien - (thanhtien * 0.3)) + " đ");
//                        break;
//                    case 0:
//                        ed_thanhtienHD_xuat.setText(decimalFormat.format(thanhtien * 1) + " đ");
//                        khuyenmai = 0;
//                        break;
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
//    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.menu_reset:

                return true;
            case R.id.menu_save:
                String mahd = ed_maHD_xuat.getText().toString();
                String ngay = ed_ngayHD_xuat.getText().toString();
//                formatBaoHang();
                HoaDon hoaDon = new HoaDon();
                hoaDon.setMshd(mahd);
                hoaDon.setMsnv(maNV);
                hoaDon.setPhanloaiHD(1);
                hoaDon.setNgaymua(ngay);
                if (rdo_dathanhtoan_HD.isChecked()){
                    hoaDon.setTrangthai(1);
                }
                if (rdo_chuathanhtoan_HD.isChecked()){
                    hoaDon.setTrangthai(0);
                }
                spn_sanphamxuat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        maSP=listSanpham.get(position).getMssp();
                        dongia= String.valueOf(listSanpham.get(position).getGiatien());
//                        double giaTien;
//                        double sl;
//                        double tien = 0;
//                        for (SanPham x:listSanpham){
//                            if (x.getTrangthai()>0){
//                                if (tenSP == null) {
//                                    dongia = x.getTensp() + ": " + decimalFormat.format(x.getGiatien()) + " đ";
//                                    soLuong = x.getTensp() + ": " + x.getTinhtrang() + "";
//                                    tenSP = x.getTensp();
//                                    giaTien = x.getGiatien();
//                                    sl = x.getTinhtrang();
//                                    tien = giaTien * sl;
//                                } else if (tenSP.equals("")) {
//                                    dongia = x.getTensp() + ": " + decimalFormat.format(x.getGiatien());
//                                    tenSP = x.getTensp();
//                                    soLuong = x.getTensp() + ": " + x.getTinhtrang() + "";
//                                    giaTien = x.getGiatien();
//                                    sl = x.getTinhtrang();
//                                    tien = giaTien * sl;
//                                } else {
//                                    tenSP += " , " + x.getTensp();
//                                    dongia += " , " + x.getTensp() + ": " + decimalFormat.format(x.getGiatien()) + " đ";
//                                    soLuong += " , " + x.getTensp() + ": " + x.getTinhtrang() + "";
//                                    giaTien = x.getGiatien();
//                                    sl = x.getTinhtrang();
//                                    tien += (giaTien * sl);
//                                }
//                            }
//                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                long kq = daoHoaDon.insertHoaDon(hoaDon);
                if (kq > 0) {
                    if (checkaddCTHD(hoaDon)) {
                        Toast.makeText(getApplicationContext(), "Thêm thành công hóa đơn", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Thêm chi tiết hóa đơn thất bại ", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                }


        }
        return super.onOptionsItemSelected(item);
    }

    private boolean checkaddCTHD(HoaDon hoaDon) {
        for (SanPham sanPham : listSanpham) {
            HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
            SanPham sanPham1 = (SanPham) spn_sanphamxuat.getSelectedItem();
            hoaDonChiTiet.setMssp(sanPham.getMssp());
            hoaDonChiTiet.setDongia(sanPham.getGiatien());
            hoaDonChiTiet.setSoluong(sanPham.getTinhtrang());
            hoaDonChiTiet.setMssp(sanPham1.getMssp());
            hoaDonChiTiet.setMshd(hoaDon.getMshd());
            if (rdo_khongbaohanh_HD_xuat.isChecked()){
                sanPham.setTinhtrang(0);
            }else if (rdo_6thang_HD_xuat.isChecked()){
                sanPham.setTinhtrang(1);
            } else if (RDO_12thang_HD_xuat.isChecked()) {
                sanPham.setTinhtrang(2);
            }
            hoaDonChiTiet.setGiamgia(khuyenmai);
            long kqCT = daoHoaDonCT.insertHoaDonCT(hoaDonChiTiet);
            if (kqCT < 0) {
                return false;
            }
        }
        return true;
    }
}