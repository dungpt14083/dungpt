package com.example.computermanage.UI.Hang.KhachHang;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.computermanage.Adapter.AdapterKhachHang;
import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.R;
import com.example.computermanage.UI.Hang.ActivityHang;

import java.util.ArrayList;

public class ActivityKhachHang extends AppCompatActivity {
    RecyclerView rcv_KhachHang;
    AdapterKhachHang adater;
    ArrayList<KhachHang> khachHangArrayList;
    DAOKhachHang daoKhachHang;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_khachhang);
        rcv_KhachHang = findViewById(R.id.rcy_khachhang);
        khachHangArrayList = new ArrayList<>();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(ActivityKhachHang.this);
        rcv_KhachHang.setLayoutManager(layoutManager);
        daoKhachHang = new DAOKhachHang(ActivityKhachHang.this);
        khachHangArrayList = daoKhachHang.getAll();
        adater = new AdapterKhachHang(ActivityKhachHang.this,khachHangArrayList);
        rcv_KhachHang.setAdapter(adater);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_add,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menu_add:
                startActivity(new Intent(ActivityKhachHang.this,ActivityAddKhachHang.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
