package com.example.computermanage.UI.HoaDonNhap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.computermanage.R;

public class ActivityEditHoaDonNhap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_hoa_don);
    }
}