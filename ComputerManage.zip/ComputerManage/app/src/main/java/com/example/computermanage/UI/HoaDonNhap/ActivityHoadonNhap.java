package com.example.computermanage.UI.HoaDonNhap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.example.computermanage.Adapter.AdapterHDNhap;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.MainActivity;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.R;

import java.util.ArrayList;
import java.util.List;

public class ActivityHoadonNhap extends AppCompatActivity {
    RecyclerView rcv_hoadonnhap;
    DAOHoaDon daoHoaDon;
    ArrayList<HoaDon> listHDNhap;
    AdapterHDNhap adapterHDNhap;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoadonnhap);
        addControl();
        addEvent();

    }

    private void addEvent() {
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this);
        rcv_hoadonnhap.setLayoutManager(layoutManager);
        listHDNhap=daoHoaDon.getAllNhap();
        adapterHDNhap=new AdapterHDNhap(ActivityHoadonNhap.this,listHDNhap);
        rcv_hoadonnhap.setAdapter(adapterHDNhap);
    }

    private void addControl() {

        rcv_hoadonnhap=findViewById(R.id.rcv_hoadonnhap);
        toolbar=findViewById(R.id.tb_HDNhap);
        daoHoaDon=new DAOHoaDon(this);
        listHDNhap=new ArrayList<>();
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Danh sách hóa đơn nhập");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityHoadonNhap.this, MainActivity.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_add,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_add:
                startActivity(new Intent(getApplicationContext(),ActivityAddHoaDonNhap.class));
        }
        return super.onOptionsItemSelected(item);
    }
}