package com.example.computermanage.UI.HoaDonNhap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.computermanage.Adapter.AdapterHDNhap;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.R;

import java.util.ArrayList;
import java.util.List;

public class ActivityHoadonNhap extends AppCompatActivity {
    RecyclerView rcv_hoadonnhap;
    DAOHoaDon daoHoaDon;
    ArrayList<HoaDon> listHDNhap;
    AdapterHDNhap adapterHDNhap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoadonnhap);
        addControl();
        addEvent();

    }

    private void addEvent() {
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this);
        rcv_hoadonnhap.setLayoutManager(layoutManager);
        listHDNhap=daoHoaDon.getAll();
        adapterHDNhap=new AdapterHDNhap(ActivityHoadonNhap.this,listHDNhap);
        rcv_hoadonnhap.setAdapter(adapterHDNhap);
    }

    private void addControl() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Danh sách hóa đơn nhập");
        rcv_hoadonnhap=findViewById(R.id.rcv_hoadonnhap);
        daoHoaDon=new DAOHoaDon(this);
        listHDNhap=new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_add,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_add:
                startActivity(new Intent(getApplicationContext(),ActivityAddHoaDonNhap.class));
        }
        return super.onOptionsItemSelected(item);
    }
}