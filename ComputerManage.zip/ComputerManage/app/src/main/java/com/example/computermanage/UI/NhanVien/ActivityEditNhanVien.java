package com.example.computermanage.UI.NhanVien;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.computermanage.DAO.DAONhanVien;
import com.example.computermanage.Model.NhanVien;
import com.example.computermanage.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class ActivityEditNhanVien extends AppCompatActivity {
    ImageView img_editAnhNhanVien;
    TextInputEditText ed_editmaNhanVien, ed_editPasswordOLD, ed_editPasswordNEW,ed_editRepass;
    Bitmap bitmap, bitmap1;
    byte[] image;
    LinearLayout linearCamera, linearGallery;
    ActivityResultLauncher<Intent> launcherCamera;
    ActivityResultLauncher<Intent> launcherGallery;
    DAONhanVien daoNhanVien;
    ArrayList<NhanVien> listNhanVien;
    NhanVien nhanVien;
    Drawable drawable;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_nhan_vien);
        addControl();
        addEvent();
    }



    private void addControl() {

        ed_editmaNhanVien = findViewById(R.id.ed_editmaNhanVien);
        ed_editPasswordOLD = findViewById(R.id.ed_editPasswordOLD);
        ed_editPasswordNEW = findViewById(R.id.ed_editPasswordNEW);

        ed_editRepass = findViewById(R.id.ed_editRePasswordNEW);
        getSupportActionBar().setTitle("Thêm Nhân Viên");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        daoNhanVien = new DAONhanVien(ActivityEditNhanVien.this);
        listNhanVien = new ArrayList<>();
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void addEvent() {
        SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
        String taiKhoan = preferences.getString("user", "");
        ed_editmaNhanVien.setText(taiKhoan);
        ed_editmaNhanVien.setEnabled(false);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_done,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_done:

                if(validate()>0)
                {
                SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
                String taiKhoan = preferences.getString("user", "");
                NhanVien nhanVien1 = daoNhanVien.getID(taiKhoan);
                    nhanVien1.setPassword(ed_editPasswordNEW.getText().toString());

                    long result=daoNhanVien.updateNhanVien(nhanVien1);
                    if (result>0){
                        listNhanVien.clear();
                        listNhanVien.addAll(daoNhanVien.getAll());
                        Toast.makeText(this, "Sửa thành công", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ActivityEditNhanVien.this,ActivityNhanVien.class));
                    }else {
                        Toast.makeText(this, "Sửa thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"vui lòng nhập lại thông tin",Toast.LENGTH_SHORT).show();
                    ed_editPasswordNEW.setText("");
                    ed_editRepass.setText("");
                    ed_editPasswordOLD.setText("");
                }


        }
        return super.onOptionsItemSelected(item);
    }
    public int validate()
    {
        int check =1;

        if(ed_editPasswordNEW.getText().length()==0&&ed_editPasswordOLD.getText().length()==0)
        {
            check = -1;
            Toast.makeText(getApplicationContext(),"bạn cần nhập đủ thông tin",Toast.LENGTH_SHORT).show();
        }


         else  {
            SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
            String matkhau = preferences.getString("pass", "");
            String mkmoi = ed_editPasswordNEW.getText().toString();
            String remk = ed_editRepass.getText().toString();
            if(!ed_editPasswordOLD.getText().toString().equals(matkhau))
            {
                Toast.makeText(getApplicationContext(),"mật khẩu cũ sai",Toast.LENGTH_SHORT).show();
                check = -1;
            }
           else if(!mkmoi.equals(remk))
            {
                Toast.makeText(getApplicationContext(),"mật khẩu không trùng khớp",Toast.LENGTH_SHORT).show();
                check = -1;
            }

        }

        return check;
    }
}