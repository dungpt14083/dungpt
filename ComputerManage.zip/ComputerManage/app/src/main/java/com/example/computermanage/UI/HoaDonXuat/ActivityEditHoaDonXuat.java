package com.example.computermanage.UI.HoaDonXuat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.DAO.DAOHoaDonCT;
import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.DAO.DAOSanPham;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.Model.HoaDonChiTiet;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.Model.SanPham;
import com.example.computermanage.R;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ActivityEditHoaDonXuat extends AppCompatActivity {
    Toolbar toolbar;
    TextInputEditText ed_editmaHD_xuat, ed_editngayHD,
            ed_editsoluongHD_xuat, ed_editdongiaHD_xuat, ed_editthanhtienHD;
    Spinner spn_editSPXuat, spn_editKHXuat, spn_editKMXuat;
    RadioButton rdo_editdathanhtoan_HD, rdo_editchuathanhtoan_HD, rdo_editkhongbaohanh_DH, rdo_edit6thang_HD, rdo_edit12thang_HD;
    DAOHoaDon daoHoaDon;
    DAOHoaDonCT daoHoaDonCT;
    DAOSanPham daoSanPham;
    DAOKhachHang daoKhachHang;
    ArrayList<SanPham> listSanpham = new ArrayList<>();
    ArrayList<KhachHang> listKhachhang;
    String mahdxuat;
    double thanhtien;
    int khuyenmai;
    private String maSP;
    private double dongia;
    private int soluong;
    HoaDon hoaDon;
    SanPham sanPham;
    KhachHang khachHang;
    HoaDonChiTiet hoaDonChiTiet;
    DecimalFormat decimalFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_hoa_don_xuat);
        addControl();
        setData();
        setDataSpinner();
    }


    private void addControl() {
        toolbar = findViewById(R.id.tb_editHDXuat);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityEditHoaDonXuat.this, ActivityHoadonXuat.class));
            }
        });
        ed_editmaHD_xuat = findViewById(R.id.ed_editmaHD_xuat);
        ed_editngayHD = findViewById(R.id.ed_editngayHD);
        ed_editsoluongHD_xuat = findViewById(R.id.ed_editsoluongHD_xuat);
        ed_editdongiaHD_xuat = findViewById(R.id.ed_editdongiaHD_xuat);
        ed_editthanhtienHD = findViewById(R.id.ed_editthanhtienHD);
        spn_editSPXuat = findViewById(R.id.spn_editSPXuat);
        spn_editKHXuat = findViewById(R.id.spn_editKHXuat);
        spn_editKMXuat = findViewById(R.id.spn_editKMXuat);
        rdo_editdathanhtoan_HD = findViewById(R.id.rdo_editdathanhtoan_HD);
        rdo_editchuathanhtoan_HD = findViewById(R.id.rdo_editchuathanhtoan_HD);
        rdo_editkhongbaohanh_DH = findViewById(R.id.rdo_editkhongbaohanh_DH);
        rdo_edit6thang_HD = findViewById(R.id.rdo_edit6thang_HD);
        rdo_edit12thang_HD = findViewById(R.id.rdo_edit12thang_HD);
        daoHoaDon = new DAOHoaDon(this);
        daoHoaDonCT = new DAOHoaDonCT(this);
        daoKhachHang = new DAOKhachHang(this);
        daoSanPham = new DAOSanPham(this);

        listSanpham = daoSanPham.getAll();
        ArrayAdapter adapterSanpham = new ArrayAdapter(ActivityEditHoaDonXuat.this, android.R.layout.simple_spinner_dropdown_item, listSanpham);
        spn_editSPXuat.setAdapter(adapterSanpham);

        listKhachhang = daoKhachHang.getAll();
        ArrayAdapter adapterKhachhang = new ArrayAdapter(ActivityEditHoaDonXuat.this, android.R.layout.simple_spinner_dropdown_item, listKhachhang);
        spn_editKHXuat.setAdapter(adapterKhachhang);
        decimalFormat = new DecimalFormat("###,###,###");

    }

    private double Thanhtien() {
        try {
            double soluong = Double.parseDouble(ed_editsoluongHD_xuat.getText().toString());
            double dongia = Double.parseDouble(ed_editdongiaHD_xuat.getText().toString());
            thanhtien = soluong * dongia;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return thanhtien;
    }

    private void addEvent() {
        ed_editsoluongHD_xuat.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                Thanhtien();
                if (!b) {
                    if (Thanhtien() != 0) {
                        ed_editthanhtienHD.setText(decimalFormat.format(Thanhtien()) + "");
                    } else {
                        ed_editthanhtienHD.setText("Null");
                    }
                }
            }
        });
    }

    private void setDataSpinner() {
        spn_editSPXuat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maSP = String.valueOf(listSanpham.get(position).getMssp());
                dongia = listSanpham.get(position).getGiatien();
                try {
                    soluong = Integer.parseInt(ed_editsoluongHD_xuat.getText().toString());
                } catch (NumberFormatException ex) { // handle your exception

                }
                ed_editsoluongHD_xuat.setText(soluong + "");
                ed_editdongiaHD_xuat.setText(dongia + "");
                thanhtien = dongia * soluong;
                ed_editthanhtienHD.setText(thanhtien + "");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        addEvent();

    }

    private void setData() {
        setSpinnerKM();
        Intent intent = getIntent();
        mahdxuat = intent.getStringExtra("mahoaddonxuat");
        hoaDon = daoHoaDon.getID(mahdxuat);
        ed_editmaHD_xuat.setText(hoaDon.getMshd());
        ed_editngayHD.setText(hoaDon.getNgaymua());
        hoaDonChiTiet = daoHoaDonCT.getID(hoaDon.getMshd());
        sanPham = daoSanPham.getID(hoaDonChiTiet.getMssp());
        int vitri = -1;
        for (int i = 0; i < listSanpham.size(); i++) {
            if (listSanpham.get(i).getMssp().equals(hoaDonChiTiet.getMssp())) {
                vitri = i;
                break;
            }
        }
        spn_editSPXuat.setSelection(vitri);
        khachHang = daoKhachHang.getID(hoaDon.getMskh());
        int vitri1 = -1;
        for (int i = 0; i < listKhachhang.size(); i++) {
            if (listKhachhang.get(i).getMskh().equals(hoaDon.getMskh())) {
                vitri1 = i;
                break;
            }
        }
        spn_editKHXuat.setSelection(vitri1);
        ed_editsoluongHD_xuat.setText(hoaDonChiTiet.getSoluong() + "");
        ed_editdongiaHD_xuat.setText(decimalFormat.format(hoaDonChiTiet.getDongia()) + "");
        switch (hoaDonChiTiet.getGiamgia()) {
            case 0:
                spn_editKMXuat.setSelection(0);
                break;
            case 1:
                spn_editKMXuat.setSelection(1);
                break;
            case 2:
                spn_editKMXuat.setSelection(2);
                break;
            case 3:
                spn_editKMXuat.setSelection(3);
                break;
            case 4:
                spn_editKMXuat.setSelection(4);
                break;
            case 5:
                spn_editKMXuat.setSelection(5);
                break;
            case 6:
                spn_editKMXuat.setSelection(6);
                break;
        }
        switch (hoaDonChiTiet.getBaohanh()) {
            case 0:
                rdo_editkhongbaohanh_DH.setChecked(true);
                break;
            case 1:
                rdo_edit6thang_HD.setChecked(true);
                break;
            case 2:
                rdo_edit12thang_HD.setChecked(true);
                break;
        }
        switch (hoaDon.getTrangthai()) {
            case 0:
                rdo_editchuathanhtoan_HD.setChecked(true);
                break;
            case 1:
                rdo_editdathanhtoan_HD.setChecked(true);
                break;

        }


    }

    private void setSpinnerKM() {
        ArrayAdapter<CharSequence> spAdapter = ArrayAdapter.createFromResource(this, R.array.khuyenmai, R.layout.custom_item_sp);
        spAdapter.setDropDownViewResource(R.layout.custom_item_sp_drop_down);
        spn_editKMXuat.setAdapter(spAdapter);
        spn_editKMXuat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        khuyenmai = 1;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.05)));
                        break;
                    case 2:
                        khuyenmai = 2;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.1)));
                        break;
                    case 3:
                        khuyenmai = 3;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.15)));
                        break;
                    case 4:
                        khuyenmai = 4;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.2)));
                        break;
                    case 5:
                        khuyenmai = 5;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.25)));
                        break;
                    case 6:
                        khuyenmai = 6;
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien - (thanhtien * 0.3)));
                        break;
                    case 0:
                        ed_editthanhtienHD.setText(decimalFormat.format(thanhtien * 1));
                        khuyenmai = 0;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_done, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.menu_reset:

                return true;
            case R.id.menu_done:
                String mahd = ed_editmaHD_xuat.getText().toString();
                String ngay = ed_editngayHD.getText().toString();
                hoaDon.setMshd(mahd);
                khachHang = (KhachHang) spn_editKHXuat.getSelectedItem();
                hoaDon.setMskh(String.valueOf(khachHang.getMskh()));
                hoaDon.setNgaymua(ngay);
                if (rdo_editdathanhtoan_HD.isChecked()) {
                    hoaDon.setTrangthai(1);
                }
                if (rdo_editchuathanhtoan_HD.isChecked()) {
                    hoaDon.setTrangthai(0);
                }
                long kq = daoHoaDon.updateHoaDon(hoaDon);
                if (kq > 0) {
                    if (checkaddCTHD(hoaDon)) {
                        Toast.makeText(getApplicationContext(), "Cập nhật  thành công hóa đơn", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), ActivityHoadonXuat.class));
                    } else {
                        Toast.makeText(getApplicationContext(), "Cập nhật chi tiết hóa đơn thất bại ", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                }
        }


        return super.onOptionsItemSelected(item);

    }

    private boolean checkaddCTHD(HoaDon hoaDon) {
        for (SanPham sanPham1 : listSanpham) {
            sanPham = (SanPham) spn_editSPXuat.getSelectedItem();
            hoaDonChiTiet.setMssp(String.valueOf(sanPham.getMssp()));
            hoaDonChiTiet.setDongia(sanPham1.getGiatien());
            hoaDonChiTiet.setSoluong(hoaDonChiTiet.getSoluong());
            hoaDonChiTiet.setMshd(hoaDon.getMshd());
            if (rdo_editkhongbaohanh_DH.isChecked()) {
                hoaDonChiTiet.setBaohanh(0);
            } else if (rdo_edit6thang_HD.isChecked()) {
                hoaDonChiTiet.setBaohanh(1);
            } else if (rdo_edit12thang_HD.isChecked()) {
                hoaDonChiTiet.setBaohanh(2);
            }
            hoaDonChiTiet.setGiamgia(khuyenmai);
            long kqCT = daoHoaDonCT.updateHoaDonCT(hoaDonChiTiet);
            if (kqCT < 0) {
                return false;
            }
        }
        return true;
    }
}