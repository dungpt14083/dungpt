package com.example.computermanage.UI.HoaDonXuat;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.computermanage.R;

public class ActivityEditHoaDonXuat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_hoa_don);
    }
}