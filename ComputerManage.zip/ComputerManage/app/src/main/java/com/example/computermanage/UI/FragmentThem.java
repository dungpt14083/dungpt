package com.example.computermanage.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.computermanage.MainActivity;
import com.example.computermanage.R;
import com.example.computermanage.UI.Hang.ActivityHang;
import com.example.computermanage.UI.Hang.KhachHang.ActivityKhachHang;

public class FragmentThem extends Fragment {
    TextView tv_hang,tvkhachhang;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_them, container, false);
        tv_hang = view.findViewById(R.id.tv_hang);
        tv_hang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(getContext(), ActivityHang.class));
            }
        });
        tvkhachhang = view.findViewById(R.id.tvKhachHang_Them);
        tvkhachhang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(getContext(),ActivityKhachHang.class));
            }
        });
        return view;
    }
}
