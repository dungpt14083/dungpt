package com.example.computermanage.Interface;

public interface itemHangClick {
    public void OnClick();
}
