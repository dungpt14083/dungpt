package com.example.computermanage.UI.HoaDonNhap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.computermanage.DAO.DAOAdmin;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.DAO.DAOHoaDonCT;
import com.example.computermanage.DAO.DAONhanVien;
import com.example.computermanage.DAO.DAOSanPham;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.Model.HoaDonChiTiet;
import com.example.computermanage.Model.SanPham;
import com.example.computermanage.R;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ActivityAddHoaDonNhap extends AppCompatActivity {
    ActionBar actionBar;
    TextInputEditText ed_maHD_nhap, ed_ngayHD_nhap, ed_soluongHD_nhap, ed_dongiaHD_nhap, ed_thanhtienHD_nhap;
    Spinner spn_sanpham;
    ArrayList<SanPham> listSanpham;
    ArrayList<HoaDon> listHoadon;
    DAOSanPham daoSanPham;
    DAOHoaDon daoHoaDon;
    DAONhanVien daoNhanVien;
    DAOHoaDonCT daoHoaDonCT;
    DAOAdmin daoAdmin;
    String maNV;
    DecimalFormat decimalFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hoa_don_nhap);
        addConTrol();
        eventDialog();
    }

    private void eventDialog() {
        ed_ngayHD_nhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        ed_dongiaHD_nhap.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (Thanhtien() != 0) {
                        ed_thanhtienHD_nhap.setText(decimalFormat.format(Thanhtien()) + "");
                    } else {
                        ed_thanhtienHD_nhap.setText("Null");
                    }
                }
            }
        });

        ed_soluongHD_nhap.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (Thanhtien() != 0) {
                        ed_thanhtienHD_nhap.setText(decimalFormat.format(Thanhtien()) + "");
                    } else {
                        ed_thanhtienHD_nhap.setText("Null");
                    }
                }
            }
        });


    }

    private double Thanhtien() {
        double thanhtien = 0;
        try {
            double soluong = Double.parseDouble(ed_soluongHD_nhap.getText().toString());
            double dongia = Double.parseDouble(ed_dongiaHD_nhap.getText().toString());
            thanhtien = soluong * dongia;
        } catch (Exception e) {
            thanhtien = 0;
        }
        return thanhtien;
    }

    private void addConTrol() {
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Thêm hóa đơn nhập");
        ed_maHD_nhap = findViewById(R.id.ed_maHD_nhap);
        ed_ngayHD_nhap = findViewById(R.id.ed_ngayHD_nhap);
        spn_sanpham = findViewById(R.id.spn_sanpham);
        ed_soluongHD_nhap = findViewById(R.id.ed_soluongHD_nhap);
        ed_dongiaHD_nhap = findViewById(R.id.ed_dongiaHD_nhap);
        ed_thanhtienHD_nhap = findViewById(R.id.ed_thanhtienHD_nhap);
        daoSanPham = new DAOSanPham(this);
        daoHoaDon = new DAOHoaDon(this);
        daoHoaDonCT = new DAOHoaDonCT(this);
        daoNhanVien = new DAONhanVien(this);
        daoAdmin = new DAOAdmin(this);
        listSanpham = new ArrayList<>();
        listHoadon = new ArrayList<>();

        listSanpham = daoSanPham.getAll();
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listSanpham);
        spn_sanpham.setAdapter(adapter);
        decimalFormat = new DecimalFormat("###,###,###");
    }

    public void getMaNV() {
        SharedPreferences preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
        String taiKhoan = preferences.getString("user", "");
        maNV = daoNhanVien.getID(taiKhoan).getMsnv();
        if (daoNhanVien.getID(taiKhoan).getMsnv() == null) {
            Toast.makeText(getApplicationContext(), "Chua co nhan vien", Toast.LENGTH_SHORT).show();
            return;
        } else {
            maNV = daoNhanVien.getID(taiKhoan).getMsnv();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_save, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.menu_reset:

                return true;
            case R.id.menu_save:
                String mahd = ed_maHD_nhap.getText().toString();
                getMaNV();
                String ngay = ed_ngayHD_nhap.getText().toString();
                int soLuong = Integer.parseInt(ed_soluongHD_nhap.getText().toString());
                double donGia = Double.parseDouble(ed_dongiaHD_nhap.getText().toString());

                HoaDon hoaDon = new HoaDon();
                hoaDon.setMshd(mahd);
                hoaDon.setMsnv(maNV);
                hoaDon.setPhanloaiHD(0);
                hoaDon.setNgaymua(ngay);
                hoaDon.setTrangthai(2);
                long kq = daoHoaDon.insertHoaDon(hoaDon);
                if (kq > 0) {
                    HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet();
                    SanPham sanPham = (SanPham) spn_sanpham.getSelectedItem();
                    hoaDonChiTiet.setMssp(sanPham.getMssp());
                    hoaDonChiTiet.setMshd(mahd);
                    hoaDonChiTiet.setSoluong(soLuong);
                    hoaDonChiTiet.setDongia(donGia);
                    long kqCT = daoHoaDonCT.insertHoaDonCT(hoaDonChiTiet);
                    if (kqCT > 0) {
                        SanPham sanPham1 = daoSanPham.getID(hoaDonChiTiet.getMssp());
                        sanPham1.setTrangthai(0);
                        long sp = daoSanPham.updateSanPham(sanPham1);
                        if (sp > 0) {
                            Toast.makeText(getApplicationContext(), "Thêm thành công hóa đơn", Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(getApplicationContext(), "Cap nhat trang thai that bai", Toast.LENGTH_SHORT).show();

                        }

                    } else {
                        Toast.makeText(getApplicationContext(), "Thêm thất bại hóa đơn", Toast.LENGTH_SHORT).show();

                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                }


        }
        return super.onOptionsItemSelected(item);
    }
}