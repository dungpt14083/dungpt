package com.example.computermanage.UI.Hang.KhachHang;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.computermanage.DAO.DAOKhachHang;
import com.example.computermanage.Model.KhachHang;
import com.example.computermanage.R;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class ActivityAddKhachHang extends AppCompatActivity {
    ActionBar actionBar;

    TextInputEditText ed_tenkhachhang,ed_sodienthoai,ed_makhachhang,ed_diachikhachhang;
    RadioGroup rdokh;
    RadioButton rdonam,rdonu;
    DAOKhachHang daoKhachHang;
    ArrayList<KhachHang> khachHangArrayList;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_themkhachhang);
        addcontrol();

    }
    private void addcontrol()
    {

        actionBar = getSupportActionBar();
        actionBar.setTitle("Thêm Khách Hàng");
        actionBar.setDisplayHomeAsUpEnabled(true);
        ed_tenkhachhang = findViewById(R.id.edTenKhachHang_themkhachhang);
        ed_diachikhachhang = findViewById(R.id.edDiaChiKhachHang_themkhachhang);
        ed_sodienthoai = findViewById(R.id.edsodienthoaikhachhang_themkhachhang);
        ed_makhachhang = findViewById(R.id.edMaKhachHang_themkhachhang);

        ed_makhachhang.setEnabled(false);
        rdokh = findViewById(R.id.rdogrkh);
        rdonam = findViewById(R.id.rdoNam_themkhachhang);
        rdonu = findViewById(R.id.rdoNu_themkhachhang);
        khachHangArrayList = new ArrayList<>();
        daoKhachHang = new DAOKhachHang(getApplicationContext());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_save,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menu_reset:
                ed_tenkhachhang.setText("");
                ed_sodienthoai.setText("");
                ed_diachikhachhang.setText("");
                ed_makhachhang.setText("");
            case R.id.menu_save:
                if(validate()>0)
                {
                    KhachHang itemm = new KhachHang();
                    itemm.setHoten(ed_tenkhachhang.getText().toString());
                    itemm.setDiachi(ed_diachikhachhang.getText().toString());
                    itemm.setSdt(ed_sodienthoai.getText().toString());
                    if(rdonam.isChecked()==true)
                    {
                        itemm.setGioitinh(1);
                    }
                    else {
                        itemm.setGioitinh(0);
                    }
                    long kq = daoKhachHang.insertKhachHang(itemm);
                    if(kq>0)
                    {
                        khachHangArrayList.clear();
                        khachHangArrayList.addAll(daoKhachHang.getAll());
                        Toast.makeText(this,"thêm thành công",Toast.LENGTH_SHORT).show();
                        ed_tenkhachhang.setText("");
                        ed_sodienthoai.setText("");
                        ed_diachikhachhang.setText("");
                        ed_makhachhang.setText("");
                    }
                    else {
                        Toast.makeText(this,"Thêm thất bại",Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(this,"vui lòng nhập đủ thông tin",Toast.LENGTH_SHORT).show();
                }


        }
        return true;
    }

    private int validate()
    {
        int check =1;
        if(ed_tenkhachhang.getText().length()==0)
        {
            Toast.makeText(this,"bạn không được bỏ trống tên khách hàng",Toast.LENGTH_SHORT).show();
            check=-1;
        }
        if(ed_sodienthoai.getText().length()==0)
        {
            Toast.makeText(this,"bạn không được bỏ trống sđt khách hàng",Toast.LENGTH_SHORT).show();

            check=-1;
        }
        if(ed_diachikhachhang.getText().length()==0)
        {
            Toast.makeText(this,"bạn không được bỏ trống địa chỉ khách hàng",Toast.LENGTH_SHORT).show();

            check=-1;
        }
        return check;
    }
}
