package com.example.computermanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.computermanage.DAO.DAOAdmin;

public class LoginActivity extends AppCompatActivity {
    Button btn_login;
    EditText ed_user,ed_password;
    DAOAdmin daoAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        addControl();
        addEvent();
    }

    private void addEvent() {
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLogin();
            }
        });
    }

    private void checkLogin() {
        String user = ed_user.getText().toString();
        String password = ed_password.getText().toString();
        if (user.isEmpty()){
            ed_user.setError("Tài khoản không được bỏ trống");
            return;
        }else if (password.isEmpty()){
            ed_password.setError("Mật khẩu không được bỏ trống");
            return;
        }else if (daoAdmin.checkLogin(user,password)>0){
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
            Toast.makeText(this, "Login thành công", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Tài khoản ,mật khẩu không đúng", Toast.LENGTH_SHORT).show();
        }
    }

    private void addControl() {
        btn_login = findViewById(R.id.btn_login);
        ed_user = findViewById(R.id.ed_user);
        ed_password = findViewById(R.id.ed_password);
        daoAdmin = new DAOAdmin(LoginActivity.this);
    }
}