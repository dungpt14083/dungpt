package com.example.computermanage.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.DAO.DAOHoaDonCT;
import com.example.computermanage.DAO.DAOSanPham;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.Model.HoaDonChiTiet;
import com.example.computermanage.Model.SanPham;
import com.example.computermanage.R;
import com.example.computermanage.UI.HoaDonNhap.ActivityChiTietHoaDonNhap;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AdapterHDXuat extends RecyclerView.Adapter<AdapterHDXuat.HDXuatViewHolder> {
    private Context context;
    ArrayList<HoaDon> listHDXuat;
    ArrayList<HoaDonChiTiet> listHDCTxuat;
    DAOHoaDon daoHoaDon;
    DAOSanPham daoSanPham;
    DAOHoaDonCT daoHoaDonCT;
    Drawable drawable;

    public AdapterHDXuat(Context context, ArrayList<HoaDon> listHDXuat) {
        this.context = context;
        this.listHDXuat = listHDXuat;
        daoHoaDon = new DAOHoaDon(context);
        daoSanPham = new DAOSanPham(context);
        daoHoaDonCT = new DAOHoaDonCT(context);
    }

    @NonNull
    @Override
    public HDXuatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_hoadonxuat, null);
        return new HDXuatViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull AdapterHDXuat.HDXuatViewHolder holder, int position) {
        HoaDon hoaDon = listHDXuat.get(position);
        if (hoaDon == null) {
            return;
        }
        holder.tv_maHDxuat.setText("Mã HĐ: " + hoaDon.getMshd());
        holder.tv_ngayHDXuat.setText("Ngày: " + hoaDon.getNgaymua());

        listHDCTxuat=daoHoaDonCT.getListMaHD(hoaDon.getMshd());
        if (listHDCTxuat.size()==0){
            holder.tv_khuyenmaiHDXuat.setText("null");
            holder.tv_thanhtienHDXuat.setText("null");
            holder.tv_baohangHDXuat.setText("Không bảo hành");
            holder.tv_tenHDSP_xuat.setText("Sản phẩm: ngừng kinh doanh");
            holder.tv_dongiaHDXuat.setText("Đơn giá: null");
            holder.tv_soluongHDXuat.setText("Số lượng: null");
        }else {
            String tensp="";
            int soluong=0;
            String dongia="";
            double tien=0;
            int khuyenmai=0;
            int baohanh=0;
            DecimalFormat decimalFormat=new DecimalFormat("###,###,###");
            for (HoaDonChiTiet x:listHDCTxuat){
                SanPham sanPham=daoSanPham.getID(x.getMssp());
                if (tensp.equals("")){
                    tensp= sanPham.getTensp();
                    soluong= x.getSoluong();
                    dongia= decimalFormat.format(x.getDongia());
                    tien=x.getDongia()*x.getSoluong();
                    khuyenmai=x.getGiamgia();
                    baohanh=x.getBaohanh();
                }else {
                    tensp= sanPham.getTensp();
                    soluong= x.getSoluong();
                    dongia= decimalFormat.format(x.getDongia());
                    tien+=(x.getDongia()*x.getSoluong());
                }
            }
            switch (khuyenmai){
                case 0:
                    holder.tv_khuyenmaiHDXuat.setText("Không khuyến mãi");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien)+" đ");
                    break;
                case 1:
                    holder.tv_khuyenmaiHDXuat.setText("5%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.05) + " đ");
                    break;
                case 2:
                    holder.tv_khuyenmaiHDXuat.setText("10%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.1) + " đ");
                    break;
                case 3:
                    holder.tv_khuyenmaiHDXuat.setText("15%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.15) + " đ");
                    break;
                case 4:
                    holder.tv_khuyenmaiHDXuat.setText("20%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.2) + " đ");
                    break;
                case 5:
                    holder.tv_khuyenmaiHDXuat.setText("25%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.25) + " đ");
                    break;
                case 6:
                    holder.tv_khuyenmaiHDXuat.setText("30%");
                    holder.tv_thanhtienHDXuat.setText("Thành tiền: "+decimalFormat.format(tien - tien * 0.3) + " đ");
                    break;
            }
            switch (baohanh) {
                case 0:
                    holder.tv_baohangHDXuat.setText("6 tháng BH");
                    drawable = context.getDrawable(R.drawable.ic_baohanh6t);
                    holder.img_baohanh_HDCTXuat.setImageDrawable(drawable);
                    break;
                case 1:
                    drawable = context.getDrawable(R.drawable.ic_baohanh12t);
                    holder.img_baohanh_HDCTXuat.setImageDrawable(drawable);
                    holder.tv_baohangHDXuat.setText("12 tháng BH");
                    break;
                default:
                    drawable = context.getDrawable(R.drawable.ic_kobaohanh);
                    holder.img_baohanh_HDCTXuat.setImageDrawable(drawable);
                    holder.tv_baohangHDXuat.setText("Không bảo hành");
                    break;
            }
            holder.tv_tenHDSP_xuat.setText("Sản phẩm: " + tensp);
            holder.tv_dongiaHDXuat.setText("Đơn giá: " +dongia);
            holder.tv_soluongHDXuat.setText("Số lượng: " + soluong);
        }
        switch (hoaDon.getTrangthai()) {
            case 0:
                holder.tv_trangthaiHDXuat.setText("Chưa thanh toán");
                holder.tv_trangthaiHDXuat.setTextColor(Color.RED);
                break;
            case 1:
                holder.tv_trangthaiHDXuat.setText("Đã thanh toán");
                holder.tv_trangthaiHDXuat.setTextColor(Color.GREEN);
                break;
            default:
                holder.tv_trangthaiHDXuat.setText("Chưa thanh toán");
                holder.tv_trangthaiHDXuat.setTextColor(Color.RED);
                break;
        }


//        holder.cv_chitietHDXuat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(context, ActivityChiTietHoaDonNhap.class);
//                intent.putExtra("mahdxuat", hoaDon.getMshd());
//                context.startActivity(intent);
//            }
//        });


    }

    @Override
    public int getItemCount() {
        return listHDXuat.size();
    }

    public class HDXuatViewHolder extends RecyclerView.ViewHolder {
        TextView tv_tenHDSP_xuat;
        TextView tv_maHDxuat, tv_khachhangHDXuat, tv_soluongHDXuat, tv_dongiaHDXuat, tv_khuyenmaiHDXuat
                , tv_ngayHDXuat,tv_baohangHDXuat,tv_thanhtienHDXuat,tv_trangthaiHDXuat;
        CardView cv_chitietHDXuat;
        ImageView img_baohanh_HDCTXuat;

        public HDXuatViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_tenHDSP_xuat = itemView.findViewById(R.id.tv_tenHDSP_xuat);
            tv_maHDxuat = itemView.findViewById(R.id.tv_maHDxuat);
            tv_khachhangHDXuat = itemView.findViewById(R.id.tv_khachhangHDXuat);
            tv_soluongHDXuat = itemView.findViewById(R.id.tv_soluongHDXuat);
            tv_dongiaHDXuat = itemView.findViewById(R.id.tv_dongiaHDXuat);
            tv_khuyenmaiHDXuat = itemView.findViewById(R.id.tv_khuyenmaiHDXuat);
            tv_ngayHDXuat = itemView.findViewById(R.id.tv_ngayHDXuat);
            tv_baohangHDXuat = itemView.findViewById(R.id.tv_baohangHDXuat);
            tv_thanhtienHDXuat = itemView.findViewById(R.id.tv_thanhtienHDXuat);
            tv_trangthaiHDXuat = itemView.findViewById(R.id.tv_trangthaiHDXuat);
            cv_chitietHDXuat = itemView.findViewById(R.id.cv_chitietHDXuat);
            img_baohanh_HDCTXuat = itemView.findViewById(R.id.img_baohanh_HDCTXuat);


        }
    }

    public int getRandomColor() {
        Random rnd = new Random();
        return Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
    }
}
