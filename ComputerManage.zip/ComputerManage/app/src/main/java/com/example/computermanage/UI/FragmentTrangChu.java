package com.example.computermanage.UI;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.computermanage.Adapter.AdapterSlider;
import com.example.computermanage.R;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

public class FragmentTrangChu extends Fragment {
//    SliderView sliderView;
//    int[] image = {
//            R.drawable.image1,
//            R.drawable.image2,
//            R.drawable.image3,
//            R.drawable.image4,
//            R.drawable.image5,
//            R.drawable.image6,
//            R.drawable.image7,
//    };
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_trangchu,container,false);
//        sliderView = view.findViewById(R.id.image_slider);
//        AdapterSlider adapterSlider = new AdapterSlider(image);
//        sliderView.setSliderAdapter(adapterSlider);
//        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
//        sliderView.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
//        sliderView.startAutoCycle();
        return view;
    }
}
