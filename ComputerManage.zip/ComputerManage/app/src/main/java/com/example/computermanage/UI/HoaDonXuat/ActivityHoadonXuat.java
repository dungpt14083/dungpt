package com.example.computermanage.UI.HoaDonXuat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.computermanage.Adapter.AdapterHDNhap;
import com.example.computermanage.Adapter.AdapterHDXuat;
import com.example.computermanage.DAO.DAOHoaDon;
import com.example.computermanage.Model.HoaDon;
import com.example.computermanage.R;

import java.util.ArrayList;

public class ActivityHoadonXuat extends AppCompatActivity {
    RecyclerView rcv_hoadonxuat;
    DAOHoaDon daoHoaDon;
    ArrayList<HoaDon> listHDXuat;
    AdapterHDXuat adapterHDXuat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoadonxuat);
        addControl();
        addEvent();

    }

    private void addEvent() {
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this);
        rcv_hoadonxuat.setLayoutManager(layoutManager);
        listHDXuat=daoHoaDon.getAll();
        adapterHDXuat=new AdapterHDXuat(ActivityHoadonXuat.this,listHDXuat);
        rcv_hoadonxuat.setAdapter(adapterHDXuat);
    }

    private void addControl() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Danh sách hóa đơn xuất");
        rcv_hoadonxuat=findViewById(R.id.rcv_hoadonxuat);
        daoHoaDon=new DAOHoaDon(this);
        listHDXuat=new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_add,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_add:
                startActivity(new Intent(getApplicationContext(), ActivityAddHoaDonXuat.class));
        }
        return super.onOptionsItemSelected(item);
    }
}